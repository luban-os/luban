// #############################################################################
// *****************************************************************************
//                  Copyright (c) 2014, Advantech Automation Corp.
//      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
//               INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
//
//    ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
//               ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
// *****************************************************************************
// #############################################################################
//
// File:    AdsLED.h
// Author:  Liu Kun
// Created: 03/17/2015   16:44
//
// Description:  AdsLED class header file.
// -----------------------------------------------------------------------------

#ifndef ADSLED_INC
#define ADSLED_INC


#ifdef __cplusplus
extern "C"

{
#endif


#define MAX_LED_COUNT	8

// -----------------------------------------------------------------------------
// DESCRIPTION: Define Status Code
// -----------------------------------------------------------------------------
#define SUCCESS                  0
#define ERROR_OPEN_DEVICE       ( SUCCESS + 2 )
#define ERROR_INVALID_HANDLE	( SUCCESS + 3 )
#define ERROR_INVALID_PORTNUM	( SUCCESS + 4 )


// -----------------------------------------------------------------------------
// DESCRIPTION: Open the Programmable LED device
// -----------------------------------------------------------------------------
long  LED_DeviceOpen ( long *driver_handle );

// -----------------------------------------------------------------------------
// DESCRIPTION: Close the Programmable LED device
// -----------------------------------------------------------------------------
long  LED_DeviceClose ( long *driver_handle );

// -----------------------------------------------------------------------------
// DESCRIPTION: Get the Programmable LED count
// -----------------------------------------------------------------------------
long  LED_GetCount( 
                   long driver_handle,
                   unsigned long * count	// LED count
                   );

// -----------------------------------------------------------------------------
// DESCRIPTION: Get the Programmable LED Status
// -----------------------------------------------------------------------------
long  LED_GetStatus( 
                    long driver_handle,
                    unsigned short uIndex,	// Port Index
                    unsigned char * bOn	    // On or Off
                    );

// -----------------------------------------------------------------------------
// DESCRIPTION: Set the Programmable LED Status On
// -----------------------------------------------------------------------------
long  LED_On ( 
              long driver_handle,
              unsigned short uIndex	    // Port Index
              );

// -----------------------------------------------------------------------------
// DESCRIPTION: Set the Programmable LED Status Off
// -----------------------------------------------------------------------------
long  LED_Off ( 
               long driver_handle,
               unsigned short uIndex	// Port Index 
               );

#ifdef __cplusplus
}
#endif


#endif // #ifndef ADSLED_INC
