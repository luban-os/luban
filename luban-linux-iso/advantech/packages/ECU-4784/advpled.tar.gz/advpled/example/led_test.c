#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <stdbool.h>

#include "adsled.h"


long fd = -1;

void select_menu(void)
{
	printf( 
        "<0>\t Exit.\n"
        "<1>\t Get led Counts.\n"
        "<2>\t Get led Status.\n"
        "<3>\t Set led On.\n"
        "<4>\t Set led Off.\n"
	);
}

int main(int argc, char *argv[])
{
	unsigned long ret = 0;
	int i;

  	unsigned long gpio_count = 0;
	unsigned short index = 0;	
	unsigned char bOn = 0;
	
	ret = LED_DeviceOpen(&fd);

	if (ret != 0)
    {
		printf("Failed to open the Programmable LED (adsled) Device!\n");
		return ret;
	}

	do
	{
		printf("\n--------------------------------\n");
		select_menu();
		printf("\n\tSelect :\t");
		scanf("%d", &i);
		fflush(stdin);
		if (i < 0 || i > 4) 
		{
			LED_DeviceClose(&fd);
			return -1;
		}

		switch (i)
		{
        case 0:
            LED_DeviceClose(&fd);	
            printf("Exit.\n");
            return 0;
        case 1:
            ret = LED_GetCount(fd,&gpio_count);
            if (ret != 0)
            {
				printf("Get LED count Failed! ret: %lu\n", ret);
				LED_DeviceClose(&fd);
                return ret;
            }
            printf("\tLED counts:\t%lu\n", gpio_count);
            break;
        case 2:
            printf("\n\tSelect index (0 - 7):\t");
            scanf("%hu", &index);

            ret = LED_GetStatus(fd, index, &bOn);
            if (ret == 4)
            {
                printf("Invalid Channel Index.\n");
				LED_DeviceClose(&fd);
                return ret;
            }

            else if(ret != 0)
            {
                printf("Get status Failed! ret: %lu\n", ret);
				LED_DeviceClose(&fd);
                return ret;
            }

            printf("\tThe %dth led status:\t%d\n", index, bOn);	
            break;

        case 3:
            printf("\n\tSelect index (0 - 7):\t");
            scanf("%hu", &index);	

            ret = LED_On(fd, index);

            if (ret == 4)
            {
                printf("Invalid Channel Index.\n");
				LED_DeviceClose(&fd);
                return ret;
            }

            else if(ret != 0)
            {
                printf("LED On Failed! ret: %lu\n", ret);
				LED_DeviceClose(&fd);
                return ret;
            }

            break;

        case 4:
            printf("\n\tSelect index (0 - 7):\t");
            scanf("%hu", &index);

            ret = LED_Off(fd, index);

            if (ret == 4)
            {
                printf("Invalid Channel Index.\n");
				LED_DeviceClose(&fd);
                return ret;
            }

            else if(ret != 0)
            {
                printf("LED Off Failed! ret: %lu\n", ret);
				LED_DeviceClose(&fd);
                return ret;
            }

            break;

        default:
            printf("Please input: 0 -- 4.\n");
            break;
		}

	}while ((i >= 0) && (i <= 4));

	LED_DeviceClose(&fd);	
	return 0;
}
