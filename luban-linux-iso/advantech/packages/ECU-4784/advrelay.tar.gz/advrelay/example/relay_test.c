#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>

#include "adsrelay.h"


void select_menu(void)
{
	printf( 
        "** Switching Relay state needs a little time. \n"
        "** Please after heard a crack, for other operations.\n"
        "\t 0.  Exit.\n"
        "\t 1.  Get the Relay-out Status.\n"
        "\t 2.  Set the Relay-out On.\n"
        "\t 3.  Set the Relay-out Off.\n"
	);
}

int main(int argc, char *argv[])
{
	unsigned long ret = 0;
	long fd = -1;
    unsigned char bOn = 0;
	int i;
	
	ret = Relay_DeviceOpen(&fd);

	if (ret != 0)
    {
		printf("Failed to open the Relay-out (adsrelay) Device!\n");
		return ret;
	}

	do
	{
		printf("\n----------------------------------------------------------\n");
		select_menu();
        printf("\n\t Please enter your choice:\t");
		scanf("%d", &i);
		fflush(stdin);
		if (i < 0 || i > 4) 
		{
            Relay_DeviceClose(&fd);
			return -1;
		}

		switch (i)
		{
        case 0:
            Relay_DeviceClose(&fd);	
            printf("Exit.\n");
            return 0;
        case 1:
            ret = Relay_GetStatus( fd, &bOn);
            if (ret != 0)
            {
                printf("\t Get status Failed!\n");
				Relay_DeviceClose(&fd);
                return ret;
            }

            //sleep(1);
            printf("\t The Relay-out status:\t\t%d\n", bOn);	
            break;

        case 2:
            ret = Relay_On(fd);

            if(ret != 0)
            {
                printf("\t Relay-out On Failed!\n");
				Relay_DeviceClose(&fd);
                return ret;
            }

            //sleep(1);
            break;

        case 3:
            ret = Relay_Off(fd);

            if(ret != 0)
            {
                printf("\t Relay-out Off Failed!\n");
				Relay_DeviceClose(&fd);
                return ret;
            }

            //sleep(1);
            break;

        default:
            printf("Please input: 0 -- 3.\n");
            break;
		}

	}while ((i >= 0) && (i < 4));

	Relay_DeviceClose(&fd);	
	return 0;
}
