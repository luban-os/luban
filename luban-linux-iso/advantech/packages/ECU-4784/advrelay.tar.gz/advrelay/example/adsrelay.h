// #############################################################################
// *****************************************************************************
//                  Copyright (c) 2014, Advantech Automation Corp.
//      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
//               INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
//
//    ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
//               ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
// *****************************************************************************
// #############################################################################
//
// File:    adsrelay.h
// Author:  Liu Kun
// Created: 03/17/2015   16:44
//
// Description:  adsrelay class header file.
// -----------------------------------------------------------------------------

#ifndef ADSRELAY_INC
#define ADSRELAY_INC


#ifdef __cplusplus
extern "C"

{
#endif


// -----------------------------------------------------------------------------
// DESCRIPTION: Define Status Code
// -----------------------------------------------------------------------------
#define SUCCESS                  0
#define ERROR_OPEN_DEVICE       ( SUCCESS + 2 )
#define ERROR_INVALID_HANDLE	( SUCCESS + 3 )


// -----------------------------------------------------------------------------
// DESCRIPTION: Open the Relay-out device
// -----------------------------------------------------------------------------
long  Relay_DeviceOpen ( long *driver_handle );

// -----------------------------------------------------------------------------
// DESCRIPTION: Close the Relay-out device
// -----------------------------------------------------------------------------
long  Relay_DeviceClose ( long *driver_handle );

// -----------------------------------------------------------------------------
// DESCRIPTION: Get the Relay-out Status
// -----------------------------------------------------------------------------
long  Relay_GetStatus ( long driver_handle, unsigned char * value );

// -----------------------------------------------------------------------------
// DESCRIPTION: Set the Relay-out Status On
// -----------------------------------------------------------------------------
long  Relay_On ( long driver_handle );

// -----------------------------------------------------------------------------
// DESCRIPTION: Set the Relay-out Status Off
// -----------------------------------------------------------------------------
long  Relay_Off ( long driver_handle );

#ifdef __cplusplus
}
#endif


#endif // #ifndef ADSRELAY_INC
