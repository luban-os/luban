#ifndef _ADVWDT_H
#define _ADVWDT_H


#define WDIOC_CONFIG            _IOWR(WATCHDOG_IOCTL_BASE, 11, int)
#define WDIOC_ENABLE_WDTDO      _IOWR(WATCHDOG_IOCTL_BASE, 12, int)
#define WDIOS_CLR_ALARM         0x0004 

typedef struct {
 unsigned int timeout_period;
 unsigned int event_level;
 unsigned int reboot_level;
 unsigned int enable_wdt_dio;
 unsigned int alarm_status;
} PERIOD;

#endif
