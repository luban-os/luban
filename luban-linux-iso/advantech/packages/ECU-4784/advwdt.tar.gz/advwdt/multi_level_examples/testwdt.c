
#include <stdio.h>
#include <stdarg.h>
#include <getopt.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/types.h>
#include <linux/watchdog.h>
#include <linux/errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include "advwdt.h"

//#define ADVANTECH_DEBUG
#ifdef ADVANTECH_DEBUG
#define DEBUGPRINT     printf
#else
#define DEBUGPRINT(a, ...)
#endif


int fd;
int f_enable = 0, f_disable = 0,timeout = 45, timeout_level = 1,f_clear_alarm = 0,f_timeout = 0;
int f_application = 0, f_digout = 0;

int bRunning = 0;




/*
 * This function simply sends an IOCTL to the driver, which in turn ticks
 * the PC WDT to reset its internal timer so it doesn't trigger
 * a computer reset.
 */
void keep_alive ( void )
{
   ioctl( fd, WDIOC_KEEPALIVE, NULL );
}

void usage ( char *filename )
{
   printf("Usage: #%s [OPTIONS]\n", filename);
   printf("OPTIONS:\n");
   printf(" -d: Disable WDT\n");
   printf(" -e: Enable WDT\n");
   printf(" -s SEC: Set timeout\n");
   printf(" following parameters is optional parameters should be used with '-e' or '-s'\n");
   printf(" -l [1-7]: watchdog level(default is 1)\n");
   printf(" -a: use application mode(default is system mode)\n");
   printf(" -o: enable digital output\n");
}


void clear_alarm ()
{
   int i_clear;
   i_clear = WDIOS_CLR_ALARM ;
   ioctl( fd, WDIOC_SETOPTIONS, &i_clear );
}
void disable ( void )
{
   int i_dis;
   write( fd, "V", 1 );
   i_dis = WDIOS_DISABLECARD;
   ioctl( fd, WDIOC_SETOPTIONS, &i_dis );
}



static struct option long_options[] = {
	{"disable", no_argument, NULL, 'd'},
	{"enable", no_argument, NULL, 'e'},
	{"timeout", optional_argument, NULL, 's'},
	{"level", required_argument, NULL, 'l'},
	{"application", optional_argument, NULL, 'a'},
	{"digital", optional_argument, NULL, 'o'},
	{0, 0, 0, 0}
};

void *EventThread(void *arg)
{

    int retval = 0;
    fd_set fds;
    struct timeval waitTime;
    PERIOD tmp_period;
    int select_result;
    FILE *log;

    DEBUGPRINT("enter thread EventThread\n");
    while(bRunning)
	{
		FD_ZERO(&fds);
		FD_SET(fd, &fds);
		waitTime.tv_sec = 255;
		waitTime.tv_usec = 0;
		select_result = select(fd + 1, &fds, 0, 0, &waitTime);
		if(select_result == 0)
                {
		        printf("Thread has no more event\n");
			continue;
		}
		else if (select_result < 0)
		{
			
		        printf("select error\n");
			continue;
		}
                else
		{	
			printf("receive a event\n");
			retval = ioctl( fd,WDIOC_GETSTATUS , &tmp_period );
   			if ( retval != 0 )
   			{
				printf("get watchdog stauts failed\n");
				exit(-1);
    			}
		}
	}

	f_application = 0;
	pthread_exit(0);
	return 0;

}

void *AlarmThread(void *param)
{

    int retval = 0;
    PERIOD tmp_period;
    FILE *log;
    int EventHandle = (int)param;

    while(bRunning)
	{
		sleep(1);
		retval = ioctl(fd,WDIOC_GETSTATUS , &tmp_period );
   		if ( retval != 0 )
   		{
			printf("get watchdog stauts failed\n");
			exit(-1);
    		}
		if (tmp_period.alarm_status == 1 )			
			printf("timeout alarm\n");
			
	}
	pthread_exit(0);
	return 0;

}










/*
 * The main program. Run the program with "-d" to disable the card,
 * or "-e" to enable the card.
 */
int main ( int argc, char *argv[] )
{
   int retval = 0; 
   int i_en,c;
   int option_index = 0;
   PERIOD period;
   struct timeval tv;
   fd_set rfds;
   char buf[ 256 ];

   pthread_t EventThreadHandle,AlarmThreadHandle;
   int CreateThreadResult = -1;
   struct sched_param ThreadParam;
   int PortHandle = -1;
   pthread_attr_t ThreadAttr;




   period.event_level = 0;
   period.timeout_period = 45;
   period.reboot_level = 1;
   period.enable_wdt_dio = 0;
   period.alarm_status = 0;


	if ( argc < 2 )
        {
        	usage(argv[ 0 ]);
        	exit(0);
        }
	while(1)
	{
	    c = getopt_long (argc, argv, 
			"deaos:l:",
            long_options, &option_index);
            if (c == -1)
        	break;
		switch (c)
		{ 
			case 0:
				
				if (long_options[option_index].flag != 0)
					break;
				printf ("option %s", long_options[option_index].name);
				if (optarg)
					printf (" with arg %s", optarg);
				printf ("\n");
				break;
			case 'd':
				if (optarg)
					printf("option s sould not have extra parameter\n");
				 f_disable = 1;
				break;
			case 'e':
				if (f_timeout)
				{
					printf("not allow 'e' and  's' use at the same time\n");
				}	
				if (optarg)
					printf("option r sould not have extra parameter\n");
				f_enable = 1;
				break;
			case 'c':
				if (optarg)
					printf("option r sould not have extra parameter\n");
				f_clear_alarm = 1;
				break;
			case 's':
				if (f_enable)
				{
					printf("not allow 'e' and  's' use at the same time\n");
				}	
				timeout = atoi(optarg);
				if(timeout > 255 || timeout < 1)
				{
					printf("time value should be from 1 to 255\n");
					return -1;
				}
				f_timeout = 1;
				break;
			case 'l':
				timeout_level = atoi(optarg);
				if(timeout_level > 7 || timeout_level < 1)
				{
					printf("timeout level should be from 1 to 7\n");
					return -1;
				}
				period.reboot_level = timeout_level;
				break;

			case 'a':
				if (optarg)
					printf("option a sould not have extra parameter\n");
				f_application = 1;
				break;

			case 'o':
				if (optarg)
					printf("option o sould not have extra parameter\n");
				f_digout = 1;
				break;
			case '?':
				break;
			default:
				printf("invalid parameters\n");
				usage(argv[ 0 ]);
				return -2;
				break;
		}
	}




  fd = open( "/dev/multi_watchdog", O_WRONLY );
   if ( fd == -1 ) 
   {
      printf( "WDT device not availabale.\n" );
      exit( -1 );
   }


//for further implemented 


   if( f_application == 1 )
   {

	bRunning =  1;
	ThreadParam.sched_priority = 1;
	pthread_attr_init(&ThreadAttr);
	pthread_attr_setschedparam(&ThreadAttr, &ThreadParam);
	CreateThreadResult = pthread_create(&EventThreadHandle,
			&ThreadAttr, &EventThread, NULL);
	if(CreateThreadResult != 0) {
	printf("Create event Thread Failed!\n");
		exit(-1);
	
         }
	CreateThreadResult = pthread_create(&AlarmThreadHandle,
			&ThreadAttr, &AlarmThread, NULL);
	if(CreateThreadResult != 0) {
	printf("Create alarm Thread Failed!\n");
		exit(-1);
	}
         period.event_level = 1;
   }	



   if( f_digout == 1 )
	period.enable_wdt_dio = 1;

   retval = ioctl( fd,WDIOC_CONFIG , &period );
   if ( retval != 0 )
   {
	printf("config watchdog failed\n");
	exit(-1);
    }

   if ( f_disable == 1 ) 
   {  
      disable();
   }
   else if ( f_enable == 1) 
   { 
      int i_en;
      i_en = WDIOS_ENABLECARD;
      retval = ioctl( fd, WDIOC_SETOPTIONS, &i_en );
      if ( retval != 0 )
      {
         disable();
         exit( -1 );
      }
      
      printf( "WDT enabled.\n" );
      ioctl( fd, WDIOC_GETTIMEOUT, &timeout );
      printf("WDT timeout has been set to %d seconds.\n"
             "This sample program will reset WDT every one second.\n",
             timeout );            
      printf("You can type 'd' and press Enter to disable WDT.\n");
      if ((period.reboot_level > 1) &&( f_application == 1 ))
      	printf("You can type 'c' and press Enter to clear WDT alarm.\n");
      while ( 1 )
      {
         keep_alive();
         /* Watch stdin (fd 0) to see when it has input. */
         FD_ZERO(&rfds);
         FD_SET(0, &rfds);
         /* Wait up to one second */
         tv.tv_sec = 1;
         tv.tv_usec = 0;

         retval = select(1, &rfds, NULL, NULL, &tv);
         /* Don't rely on the value of tv now! */
         if (retval == -1)
            perror("select()");
         else if ( retval )
         {
            /* FD_ISSET(0, &rfds) will be true. */
            if ( fgets( buf, sizeof(buf), stdin ) == NULL )
               perror("fgets()");
            else if ( buf[ 0 ] == 'd' )
            {
               disable();
               break;
            }
	    else if ( buf[ 0 ] == 'c' )
            {
               clear_alarm();
            }
            else 
               printf("Invalid input.\n"); 
         }
      }
      printf("press any key  to exit program\n");
      getchar();
      bRunning = 0;
 
   } 
   else if ( f_timeout == 1 )
   {
      if ( argc < 3 )
      { 
         printf( "The input is invalid!\n");
         disable();
         exit( -1 ); 
      } 
      retval = ioctl( fd, WDIOC_SETTIMEOUT, &timeout );
      if ( retval != 0 )
      {
         disable();	
         exit( -1 );
      }
      ioctl( fd, WDIOC_GETTIMEOUT, &timeout );
      printf( "WDT timeout has been set to %ld seconds.\n", timeout ); 
      printf( "After that, WDT will reset CPU.\n");
      printf("You can type 'd' and press Enter to disable WDT.\n");
      if ((period.reboot_level > 1) &&( f_application == 1 ))
      	printf("You can type 'c' and press Enter to clear WDT alarm.\n");
      
        while ( 1 )
      {
        // keep_alive();
         /* Watch stdin (fd 0) to see when it has input. */
         FD_ZERO(&rfds);
         FD_SET(0, &rfds);
         /* Wait up to one second */
         tv.tv_sec = 1;
         tv.tv_usec = 0;

         retval = select(1, &rfds, NULL, NULL, &tv);
         /* Don't rely on the value of tv now! */
         if (retval == -1)
            perror("select()");
         else if ( retval )
         {
            /* FD_ISSET(0, &rfds) will be true. */
            if ( fgets( buf, sizeof(buf), stdin ) == NULL )
               perror("fgets()");
            else if ( buf[ 0 ] == 'd' )
            {
               disable();
               break;
            }
	    else if ( buf[ 0 ] == 'c' )
            {
               clear_alarm();
            }
            else 
               printf("Invalid input.\n"); 
         }
      }
      printf("press any key  to exit program\n");

    
      getchar(); 
      bRunning = 0; 
   }
   else 
   {
      disable();
      usage(argv[ 0 ]);
   }
   close(fd);
   return 0;

}
