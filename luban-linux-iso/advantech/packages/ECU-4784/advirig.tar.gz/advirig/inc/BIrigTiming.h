
#ifndef _BIRIGTIMING_H_
#define _BIRIGTIMING_H_

#if defined(_WIN32) || defined(WIN32)
#include <windows.h>
#endif

#define IN
#define OUT

#if !defined(_BDAQ_NO_NAMESPACE) && defined(__cplusplus)
namespace Automation { 
    namespace IRIG {  
#endif


#ifndef _BDAQ_TYPES_DEFINED
#define _BDAQ_TYPES_DEFINED
typedef enum tagAccessMode {
    ModeRead = 0,
    ModeWrite,
    ModeWriteWithReset,
} AccessMode;

typedef enum tagPropertyId {

    CFG_DeviceLoadingTimeInit = 21,	
	CFG_FeaturePortsCount = 82,	
	CFG_FeatureDiintTriggerEdges = 86,   
	CFG_FeatureDiintOfChannels =87,     
	CFG_FeatureDiSnapEventSources = 92,

	CFG_DiintTriggerEdgeOfChannels =126,
	CFG_DoInitialStateOfPorts = 131,     

    CFG_IrigCustom = 500,
    CFG_DeviceTimingSourceType,
    CFG_DeviceTimingEnabled,
    CFG_DeviceTimingSourceConnected
}PropertyId;

typedef enum tagModuleType {
   DaqAny   = -1,
   DaqGroup = 1,
   DaqDevice,
   DaqDio = 5,
} ModuleType;

typedef struct tagMathInterval {
    long   Type; 
    double Min;
    double Max;
} MathInterval, * PMathInterval;

typedef enum tagActiveSignal {
	RisingEdge = 1,
	FallingEdge,
} ActiveSignal;

#define BioFailed(c)       ( (unsigned)(c) >= (unsigned)0xE0000000 ) 
typedef enum tagErrorCode {
   /// <summary>
   /// The operation is completed successfully. 
   /// </summary>
   Success = 0, 

   ///************************************************************************
   /// warning                                                              
   ///************************************************************************
   /// <summary>
   /// The interrupt resource is not available. 
   /// </summary>
   WarningIntrNotAvailable = 0xA0000000,

   /// <summary>
   /// The parameter is out of the range. 
   /// </summary>
   WarningParamOutOfRange = 0xA0000001,

   /// <summary>
   /// The property value is out of range. 
   /// </summary>
   WarningPropValueOutOfRange = 0xA0000002,

   /// <summary>
   /// The property value is not supported. 
   /// </summary>
   WarningPropValueNotSpted = 0xA0000003,

   /// <summary>
   /// The property value conflicts with the current state.
   /// </summary>
   WarningPropValueConflict = 0xA0000004,

   /// <summary>
   /// The value range of all channels in a group should be same, 
   /// such as 4~20mA of PCI-1724.
   /// </summary>
   WarningVrgOfGroupNotSame = 0xA0000005,
   
   ///***********************************************************************
   /// error                                                                
   ///***********************************************************************
   /// <summary>
   /// The handle is NULL or its type doesn't match the required operation. 
   /// </summary>
   ErrorHandleNotValid = 0xE0000000,

   /// <summary>
   /// The parameter value is out of range.
   /// </summary>
   ErrorParamOutOfRange = 0xE0000001,

   /// <summary>
   /// The parameter value is not supported.
   /// </summary>
   ErrorParamNotSpted = 0xE0000002,

   /// <summary>
   /// The parameter value format is not the expected. 
   /// </summary>
   ErrorParamFmtUnexpted = 0xE0000003,

   /// <summary>
   /// Not enough memory is available to complete the operation. 
   /// </summary>
   ErrorMemoryNotEnough = 0xE0000004,

   /// <summary>
   /// The data buffer is null. 
   /// </summary>
   ErrorBufferIsNull = 0xE0000005,

   /// <summary>
   /// The data buffer is too small for the operation. 
   /// </summary>
   ErrorBufferTooSmall = 0xE0000006,

   /// <summary>
   /// The data length exceeded the limitation. 
   /// </summary>
   ErrorDataLenExceedLimit = 0xE0000007,

   /// <summary>
   /// The required function is not supported. 
   /// </summary>
   ErrorFuncNotSpted = 0xE0000008,

   /// <summary>
   /// The required event is not supported. 
   /// </summary>
   ErrorEventNotSpted = 0xE0000009,

   /// <summary>
   /// The required property is not supported. 
   /// </summary>
   ErrorPropNotSpted = 0xE000000A, 

   /// <summary>
   /// The required property is read-only. 
   /// </summary>
   ErrorPropReadOnly = 0xE000000B,

   /// <summary>
   /// The specified property value conflicts with the current state.
   /// </summary>
   ErrorPropValueConflict = 0xE000000C,

   /// <summary>
   /// The specified property value is out of range.
   /// </summary>
   ErrorPropValueOutOfRange = 0xE000000D,

   /// <summary>
   /// The specified property value is not supported. 
   /// </summary>
   ErrorPropValueNotSpted = 0xE000000E,

   /// <summary>
   /// The handle hasn't own the privilege of the operation the user wanted. 
   /// </summary>
   ErrorPrivilegeNotHeld = 0xE000000F,

   /// <summary>
   /// The required privilege is not available because someone else had own it. 
   /// </summary>
   ErrorPrivilegeNotAvailable = 0xE0000010,

   /// <summary>
   /// The driver of specified device was not found. 
   /// </summary>
   ErrorDriverNotFound = 0xE0000011,

   /// <summary>
   /// The driver version of the specified device mismatched. 
   /// </summary>
   ErrorDriverVerMismatch = 0xE0000012,

   /// <summary>
   /// The loaded driver count exceeded the limitation. 
   /// </summary>
   ErrorDriverCountExceedLimit = 0xE0000013,

   /// <summary>
   /// The device is not opened. 
   /// </summary>
   ErrorDeviceNotOpened = 0xE0000014,      

   /// <summary>
   /// The required device does not exist. 
   /// </summary>
   ErrorDeviceNotExist = 0xE0000015,

   /// <summary>
   /// The required device is unrecognized by driver. 
   /// </summary>
   ErrorDeviceUnrecognized = 0xE0000016,

   /// <summary>
   /// The configuration data of the specified device is lost or unavailable. 
   /// </summary>
   ErrorConfigDataLost = 0xE0000017,

   /// <summary>
   /// The function is not initialized and can't be started. 
   /// </summary>
   ErrorFuncNotInited = 0xE0000018,

   /// <summary>
   /// The function is busy. 
   /// </summary>
   ErrorFuncBusy = 0xE0000019,

   /// <summary>
   /// The interrupt resource is not available. 
   /// </summary>
   ErrorIntrNotAvailable = 0xE000001A,

   /// <summary>
   /// The DMA channel is not available. 
   /// </summary>
   ErrorDmaNotAvailable = 0xE000001B,

   /// <summary>
   /// Time out when reading/writing the device. 
   /// </summary>
   ErrorDeviceIoTimeOut = 0xE000001C,

   /// <summary>
   /// The given signature does not match with the device current one.
   /// </summary>
   ErrorSignatureNotMatch = 0xE000001D,

   /// <summary>
   /// Undefined error 
   /// </summary>
   ErrorUndefined = 0xE000FFFF,
} ErrorCode;


typedef enum _tagEventId{

	EvtDiintChannel000 =12,
	EvtDiintChannel001,
	EvtDiintChannel002,
	EvtDiintChannel003,
	EvtDiintChannel004,
	EvtDiintChannel005,
	EvtDiintChannel006,
	EvtDiintChannel007,
	EvtIrigInterrupt = 267
		
}EventId, *PEventId;

#endif // _BDAQ_TYPES_DEFINED


typedef enum _tagIrigSourceType {
    UtcTime,
    LocalTime
}IrigSourceType;  

typedef struct _PRECISION_SYSTEMTIME
{
    long Year;
    long Month;
    long DayOfWeek;
    long Day;
    long Hour;
    long Minute;
    long Second;
    long Microseconds;
} PRECISION_SYSTEMTIME, *PPRECISION_SYSTEMTIME;

typedef signed char    int8;
typedef signed short   int16;

typedef unsigned char  uint8;
typedef unsigned short uint16;

#if defined(_WIN32) || defined(WIN32)
#  define BDAQCALL       WINAPI
#  ifndef _WIN64
      typedef signed   int  int32;
      typedef unsigned int  uint32;
#  else
      typedef signed   long int32;
      typedef unsigned long uint32;
#  endif
   typedef signed __int64   int64;
   typedef unsigned __int64 uint64;
#else
#  define BDAQCALL
   typedef signed int         int32;
   typedef unsigned int       uint32;
   typedef signed long long   int64;
   typedef unsigned long long uint64;
   typedef void *             HANDLE;
#endif

#if defined(_WIN32) || defined(WIN32) //WIN32 BEGIN
// **********************************************************
// IRIG APIs
// **********************************************************
struct BIrigLib
{
    HMODULE   instHandle;
    // global APIs
    ErrorCode (BDAQCALL *pfnDeviceGetLinkageInfo)(long,long,long*,WCHAR*,long*);
    // event APIs
    ErrorCode (BDAQCALL *pfnEventGetHandle)(HANDLE,long,HANDLE*);
    ErrorCode (BDAQCALL *pfnEventGetLastStatus)(HANDLE,long,uint32*,uint32*);
    ErrorCode (BDAQCALL *pfnEventClearFlag)(HANDLE,long,long,long);
    // property APIs
    ErrorCode (BDAQCALL *pfnPropertyRead)(HANDLE,long,uint32,void*,uint32*,uint32*);
    ErrorCode (BDAQCALL *pfnPropertyWrite)(HANDLE,long,uint32,void*,uint32);
    // device APIs
    ErrorCode (BDAQCALL *pfnDeviceOpen)(long,long,HANDLE*);
    ErrorCode (BDAQCALL *pfnDeviceClose)(HANDLE);
    ErrorCode (BDAQCALL *pfnDeviceReset)(HANDLE,long);
	ErrorCode (BDAQCALL *pfnDeviceGetModuleHandle)(HANDLE,long,long,HANDLE*);	
    ErrorCode (BDAQCALL *pfnDeviceRefreshProperties)(HANDLE);
    ErrorCode (BDAQCALL *pfnDeviceShowConfigDialogBox)(HANDLE,HWND,RECT*,long,BOOL,HWND*);
    // dio APIs
    ErrorCode (BDAQCALL *pfnDiReadPorts)(HANDLE,long,long,BYTE*);
    ErrorCode (BDAQCALL *pfnDoWritePorts)(HANDLE,long,long,BYTE*);
    ErrorCode (BDAQCALL *pfnDoReadBackPorts)(HANDLE,long,long,BYTE*);
    ErrorCode (BDAQCALL *pfnDiSnapStart)(HANDLE,long,long,long,BYTE**);
    ErrorCode (BDAQCALL *pfnDiSnapStop)(HANDLE,long);	
};

#if defined(_MSC_VER) && (_MSC_VER >= 1300)
__declspec(noinline)
#endif
__inline BOOL InitializeBioIrigLibray(BIrigLib *bIrigLib)
{
    if (bIrigLib->instHandle == NULL)
    {
        if ((bIrigLib->instHandle = LoadLibraryW(L"BioDaq.dll")) != NULL) 
        {
#define BDAQ_GET_PROC(fn) (*(FARPROC*)&bIrigLib->pfn##fn = GetProcAddress(bIrigLib->instHandle, "Adx"#fn))
            BDAQ_GET_PROC(DeviceGetLinkageInfo);
            BDAQ_GET_PROC(EventGetHandle);
            BDAQ_GET_PROC(EventGetLastStatus);
            BDAQ_GET_PROC(EventClearFlag);
            BDAQ_GET_PROC(PropertyRead);
            BDAQ_GET_PROC(PropertyWrite);
            BDAQ_GET_PROC(DeviceOpen);
            BDAQ_GET_PROC(DeviceClose);
            BDAQ_GET_PROC(DeviceReset);
            BDAQ_GET_PROC(DeviceGetModuleHandle);
            BDAQ_GET_PROC(DeviceRefreshProperties);
            
            BDAQ_GET_PROC(DiReadPorts);
            BDAQ_GET_PROC(DoWritePorts);
            BDAQ_GET_PROC(DoReadBackPorts);
            BDAQ_GET_PROC(DiSnapStart);
            BDAQ_GET_PROC(DiSnapStop);
        }
    }
    return bIrigLib->instHandle != NULL;
}

__inline BIrigLib * GetBIrigLib()
{
    static BIrigLib bIrigLib;
    return &bIrigLib;
}

//-------------------------------------------------------
// global helper APIs
//-------------------------------------------------------
__inline ErrorCode WINAPI AdxIrigDeviceGetLinkageInfo(
    IN  long            deviceParent, 
    IN  long            index,
    OUT long*           deviceNumber,
    OUT OPTIONAL WCHAR* description, 
    OUT OPTIONAL long*  subDeviceCount)
{
    if (InitializeBioIrigLibray(GetBIrigLib()))
    {
        return GetBIrigLib()->pfnDeviceGetLinkageInfo(deviceParent, index, deviceNumber, description, subDeviceCount);
    }
    return ErrorDriverNotFound;
}

//-------------------------------------------------------
// event APIs
//-------------------------------------------------------
__inline ErrorCode WINAPI AdxIrigEventGetHandle(
    IN HANDLE   handle,
    IN long     id,
    OUT HANDLE* eventHandle)
{
    return GetBIrigLib()->pfnEventGetHandle(handle, id, eventHandle);
}
__inline ErrorCode WINAPI AdxIrigEventGetLastStatus(
    IN HANDLE           handle, 
    IN long          id, 
    OUT OPTIONAL uint32* statusLParam,
    OUT OPTIONAL uint32* statusRParam)
{
    return GetBIrigLib()->pfnEventGetLastStatus(handle, id, statusLParam, statusRParam);
}
__inline ErrorCode WINAPI AdxIrigEventClearFlag(
    IN HANDLE  handle, 
    IN long id, 
    IN long    flagLParam,
    IN long    flagRParam)
{
    return GetBIrigLib()->pfnEventClearFlag(handle, id, flagLParam, flagRParam);
}

//-------------------------------------------------------
// property APIs
//-------------------------------------------------------
__inline ErrorCode WINAPI AdxIrigPropertyRead(
    IN HANDLE          handle, 
    IN PropertyId      id, 
    IN long            bufferSize,
    OUT OPTIONAL void* buffer, 
    OUT OPTIONAL uint32* dataLength,
    OUT OPTIONAL uint32* attribute)
{
    return GetBIrigLib()->pfnPropertyRead(handle, id, bufferSize, buffer, dataLength, attribute);
}
__inline ErrorCode WINAPI AdxIrigPropertyWrite(
    IN HANDLE     handle, 
    IN PropertyId id, 
    IN uint32       dataLength,
    IN void*      buffer,
    IN uint32       notifyNow)
{
    return GetBIrigLib()->pfnPropertyWrite(handle, id, dataLength, buffer, notifyNow);
}

//-------------------------------------------------------
// device APIs
//-------------------------------------------------------
__inline ErrorCode WINAPI AdxIrigDeviceOpen(
    IN long       deviceNumber,
    IN AccessMode accessMode,
    OUT HANDLE*   deviceHandle)
{
    if (InitializeBioIrigLibray(GetBIrigLib()))
    {
        return GetBIrigLib()->pfnDeviceOpen(deviceNumber, accessMode, deviceHandle);
    }
    return ErrorDriverNotFound;
}
__inline ErrorCode WINAPI AdxIrigDeviceClose(IN HANDLE deviceHandle)
{
    return GetBIrigLib()->pfnDeviceClose(deviceHandle);
}
__inline ErrorCode WINAPI AdxIrigDeviceReset(
    IN HANDLE deviceHandle, 
    IN long   state)
{
    return GetBIrigLib()->pfnDeviceReset(deviceHandle, state);
}
__inline ErrorCode WINAPI AdxIrigDeviceGetModuleHandle(
   IN HANDLE     deviceHandle,
   IN ModuleType type,
   IN long       index,
   OUT HANDLE*   moduleHandle )
{
   return GetBIrigLib()->pfnDeviceGetModuleHandle(deviceHandle, type, index, moduleHandle);
}

__inline ErrorCode WINAPI AdxIrigDeviceRefreshProperties(IN HANDLE deviceHandle)
{
    return GetBIrigLib()->pfnDeviceRefreshProperties(deviceHandle);
}
__inline ErrorCode WINAPI AdxIrigDeviceShowConfigDialogBox(
    IN HANDLE deviceHandle, 
    IN HWND   parentWindow, 
    IN RECT*  region,
    IN long   dataSource,
    IN BOOL   modal,
    OUT HWND* dialogWindow)
{
    return GetBIrigLib()->pfnDeviceShowConfigDialogBox(deviceHandle, parentWindow, region, dataSource, modal, dialogWindow);
}

__inline ErrorCode WINAPI AdxIrigDeviceTimeRead (
    IN  HANDLE deviceHandle,
    OUT PPRECISION_SYSTEMTIME precisionTime,
    OUT OPTIONAL long long *reserved 
    )
{
    return AdxIrigEventGetLastStatus(deviceHandle, EvtIrigInterrupt, (uint32*)precisionTime, (uint32*)reserved);
}
__inline ErrorCode WINAPI AdxIrigDoStatusLoadingInit(
    IN HANDLE     deviceHandle, 
    IN long       dataLength,
    IN void*      buffer,
    IN long       notifyNow
    )
{
    return GetBIrigLib()->pfnPropertyWrite(deviceHandle, CFG_DeviceLoadingTimeInit, dataLength, buffer, notifyNow);
}
//-------------------------------------------------------
// digital input/output APIs
//-------------------------------------------------------
__inline ErrorCode WINAPI AdxIrigDiReadPorts(
   IN HANDLE dioHandle,
   IN long   portStart,
   IN long   portCount,
   OUT BYTE* dataBuffer)
{
   return GetBIrigLib()->pfnDiReadPorts(dioHandle, portStart, portCount, dataBuffer);
}
__inline ErrorCode WINAPI AdxIrigDoWritePorts(
   IN HANDLE dioHandle,
   IN long   portStart,
   IN long	 portCount,
   IN BYTE*  dataBuffer)
{
   return GetBIrigLib()->pfnDoWritePorts(dioHandle, portStart, portCount, dataBuffer);
}
__inline ErrorCode WINAPI AdxIrigDoReadBackPorts(
   IN HANDLE dioHandle,
   IN long   portStart,
   IN long   portCount,
   OUT BYTE* dataBuffer)
{
   return GetBIrigLib()->pfnDoReadBackPorts(dioHandle, portStart, portCount, dataBuffer);
}
__inline ErrorCode WINAPI AdxIrigDiSnapStart(
   IN HANDLE  dioHandle,
   IN EventId id,
   IN long    portStart,
   IN long    portCount,
   OUT BYTE** dataBuffer)
{
   return GetBIrigLib()->pfnDiSnapStart(dioHandle, id, portStart, portCount, dataBuffer);
}
__inline ErrorCode WINAPI AdxIrigDiSnapStop(
   IN HANDLE  dioHandle,
   IN EventId id)
{
   return GetBIrigLib()->pfnDiSnapStop(dioHandle, id);
}


#else //NON-WIN32 BEGIN

#include <dlfcn.h>

typedef void* HMODULE;
typedef void* HANDLE;
typedef bool   BOOL;
typedef char   BYTE;
typedef char WCHAR;


#define MAXIMUM_WAIT_OBJECTS   64

#define WAIT_FAILED            ((uint32)-1)
#define WAIT_TIMEOUT           258
#define WAIT_ABANDONED_0       ((uint32)0x80)
#define WAIT_OBJECT_0          ((uint32)0x0)
#define INFINITE               -1

struct BIrigLib
{
	HMODULE	instHandle;
    ErrorCode ( *pfnDeviceGetLinkageInfo)(long,long,long*,wchar_t*,long*);
   	// device APIs
   	ErrorCode ( *pfnDeviceOpen)(long,long,HANDLE*);
   	ErrorCode ( *pfnDeviceClose)(HANDLE);	
	ErrorCode ( *pfnDeviceGetModuleHandle)(HANDLE,long,long,HANDLE*);
	// event APIs
    ErrorCode ( *pfnEventGetHandle)(HANDLE,long,HANDLE*);
    ErrorCode ( *pfnEventGetLastStatus)(HANDLE,long,uint32*,uint32*);
    ErrorCode ( *pfnEventClearFlag)(HANDLE,long,long,long);
    // property APIs
    ErrorCode ( *pfnPropertyRead)(HANDLE,long,uint32,void*,uint32*,uint32*);
    ErrorCode ( *pfnPropertyWrite)(HANDLE,long,long,void*,long);
	ErrorCode ( *pfnWaitForMultipleObjects)(HANDLE,int,HANDLE *,int,int);
 	// Digital input/output APIs
    ErrorCode ( *pfnDiReadPorts)(HANDLE,long,long,uint8*);
    ErrorCode ( *pfnDoWritePorts)(HANDLE,long,long,uint8*);
    ErrorCode ( *pfnDoReadBackPorts)(HANDLE,long,long,uint8*);
    ErrorCode ( *pfnLedOn)(HANDLE,long,long);
    ErrorCode ( *pfnLedOff)(HANDLE,long,long);	
    ErrorCode ( *pfnLedStatusRead)(HANDLE,long,long,uint8*);		
    ErrorCode ( *pfnDiSnapStart)(HANDLE,long,long,long,uint8**);
    ErrorCode ( *pfnDiSnapStop)(HANDLE,long);	

};
   
#if defined(_MSC_VER) && (_MSC_VER >= 1300)
   __declspec(noinline)
#endif
   __inline BOOL InitializeBioDaqLibray(BIrigLib *birigLib)
	  {
		 if (birigLib->instHandle == NULL)
		 {
			if ((birigLib->instHandle = dlopen("libbioirig.so", RTLD_LAZY)) != NULL) 
			{
		       //global apis	
				( *(void **)&birigLib->pfnDeviceGetLinkageInfo 		= dlsym(birigLib->instHandle, "AdxDeviceGetLinkageInfo"));

			   //device apis
				( *(void **)&birigLib->pfnDeviceOpen				= dlsym(birigLib->instHandle, "AdxDeviceOpen"));
				( *(void **)&birigLib->pfnDeviceClose 				= dlsym(birigLib->instHandle, "AdxDeviceClose"));
				//( *(void **)&birigLib->pfnDeviceReset 				       = dlsym(birigLib->instHandle, "AdxDeviceReset"));
				( *(void **)&birigLib->pfnDeviceGetModuleHandle		= dlsym(birigLib->instHandle, "AdxDeviceGetModuleHandle"));
				//event apis
				( *(void **)&birigLib->pfnEventGetHandle			= dlsym(birigLib->instHandle, "AdxEventGetHandle"));
				( *(void **)&birigLib->pfnEventGetLastStatus		= dlsym(birigLib->instHandle, "AdxEventGetLastStatus"));
				( *(void **)&birigLib->pfnEventClearFlag			= dlsym(birigLib->instHandle, "AdxEventClearFlag"));

				//property apis
				( *(void **)&birigLib->pfnPropertyRead				= dlsym(birigLib->instHandle, "AdxPropertyRead"));
				( *(void **)&birigLib->pfnPropertyWrite				= dlsym(birigLib->instHandle, "AdxPropertyWrite"));
				//DIO apis
				( *(void **)&birigLib->pfnDiReadPorts				= dlsym(birigLib->instHandle, "AdxDiReadPorts"));
				( *(void **)&birigLib->pfnDoWritePorts				= dlsym(birigLib->instHandle, "AdxDoWritePorts"));
				( *(void **)&birigLib->pfnLedOn				        = dlsym(birigLib->instHandle, "AdxLedOn"));	
				( *(void **)&birigLib->pfnLedOff				    = dlsym(birigLib->instHandle, "AdxLedOff"));	
				( *(void **)&birigLib->pfnLedStatusRead				= dlsym(birigLib->instHandle, "AdxLedStatusRead"));				
				( *(void **)&birigLib->pfnDoReadBackPorts			= dlsym(birigLib->instHandle, "AdxDoReadBackPorts"));
				( *(void **)&birigLib->pfnDiSnapStart				= dlsym(birigLib->instHandle, "AdxDiSnapStart"));
				( *(void **)&birigLib->pfnDiSnapStop				= dlsym(birigLib->instHandle, "AdxDiSnapStop"));

			   //api
		     	( *(void **)&birigLib->pfnWaitForMultipleObjects  = dlsym(birigLib->instHandle, "AdxWaitForMultipleObjects"));
								   
			}
		 }
		 return birigLib->instHandle != NULL;
	  }
   __inline BIrigLib * GetBDaqLib()
   {
	   static BIrigLib birigLib;
	   return &birigLib;
   }


   extern "C" {
      // Global APIs
    //  ErrorCode AdxDeviceGetLinkageInfo(
    //     int32   deviceParent,    /*IN*/
    //     int32   index,           /*IN*/
    //     int32   *deviceNumber,   /*OUT*/
    //     wchar_t *description,    /*OUT OPTIONAL*/
    //     int32   *subDeviceCount); /*OUT OPTIONAL*/
// for Irig
  /*    ErrorCode AdxDeviceOpen(
		int devcieNumber,
		uint32 accessMode,
		HANDLE *devcieHandle);

      ErrorCode AdxDeviceClose(
		HANDLE deviceHandle);
	  
	  ErrorCode AdxDeviceGetModuleHandle(
		 HANDLE	   deviceHandle,
		 ModuleType type,
		 long	   index,
		 HANDLE*   moduleHandle );

      ErrorCode AdxPropertyRead(
		HANDLE handle,
		uint32 propertyId,
		uint32 bufferSize,
		void *buffer,
		uint32 *dataLength,
		uint32 *attribute);

      ErrorCode AdxPropertyWrite(
		HANDLE handle,
		uint32 propertyId,
		uint32 dataLength,
		void *buffer,
		uint32 notifyNow);

      ErrorCode AdxEventGetLastStatus(
        HANDLE handle,
        uint32 eventType,
        uint32 *statusLParam,
        uint32 *statusRParam);

      ErrorCode AdxEventGetHandle(
		HANDLE handle,
		uint32 eventType,
		HANDLE *eventHandle);

      ErrorCode AdxEventClearFlag(
		HANDLE handle,
		uint32 eventType,
		uint32 flagLParam,
		uint32 flagRParam);
	  
// for dio	  
	  ErrorCode  AdxDiReadPorts(
		HANDLE dioHandle,
		long   portStart,
		long   portCount,
		uint8* dataBuffer);
	  ErrorCode  AdxDoWritePorts(
		HANDLE dioHandle,
		long   portStart,
		long   portCount,
		uint8*  dataBuffer);

	  ErrorCode  AdxDoReadBackPorts(
		HANDLE dioHandle,
		long   portStart,
		long   portCount,
		uint8* dataBuffer);

	  ErrorCode AdxDiSnapStart(
	    HANDLE  dioHandle,
	    EventId id,
	    long    portStart,
	    long    portCount,
	    uint8** dataBuffer);

	  ErrorCode  AdxDiSnapStop(
	    HANDLE  dioHandle,
	    EventId id);	*/
	  
	   }


// Change function name for irig   
//-------------------------------------------------------
// event APIs
//-------------------------------------------------------

    __inline ErrorCode AdxIrigEventGetHandle(
        IN HANDLE   handle,
        IN long     id,
        OUT HANDLE* eventHandle)
    {
        //return AdxEventGetHandle(handle, id, eventHandle);
        return GetBDaqLib()->pfnEventGetHandle(handle, id, eventHandle);   
    }
    __inline ErrorCode AdxIrigEventGetLastStatus(
        IN HANDLE           handle, 
        IN long          id, 
        OUT uint32* statusLParam,
        OUT uint32* statusRParam)
    {
       // return AdxEventGetLastStatus(handle, id, statusLParam, statusRParam);
       return GetBDaqLib()->pfnEventGetLastStatus(handle, id, statusLParam, statusRParam);   
    }
    __inline ErrorCode AdxIrigEventClearFlag(
        IN HANDLE  handle, 
        IN long id, 
        IN long    flagLParam,
        IN long    flagRParam)
    {
        //return AdxEventClearFlag(handle, id, flagLParam, flagRParam);
       return GetBDaqLib()->pfnEventClearFlag(handle, id, flagLParam, flagRParam); 
    }
//-------------------------------------------------------
// device APIs
//-------------------------------------------------------	
	__inline ErrorCode  AdxDeviceGetLinkageInfo(
	   IN  long 		   deviceParent, 
	   IN  long 		   index,
	   OUT long*		   deviceNumber,
	   OUT  wchar_t* description, 
	   OUT  long*  subDeviceCount)
	{
	   if (InitializeBioDaqLibray(GetBDaqLib()))
	   {
		  return GetBDaqLib()->pfnDeviceGetLinkageInfo(deviceParent, index, deviceNumber, description, subDeviceCount);
	   }
	   return ErrorDriverNotFound;
	}

	__inline ErrorCode AdxIrigDeviceOpen(
        IN long       deviceNumber,
        IN AccessMode accessMode,
        OUT HANDLE*   deviceHandle)
    {
        //return AdxDeviceOpen(deviceNumber, accessMode, deviceHandle);
   		if (InitializeBioDaqLibray(GetBDaqLib()))
   		{
      		return GetBDaqLib()->pfnDeviceOpen(deviceNumber, accessMode, deviceHandle);
   		}
   		return ErrorDriverNotFound;        
    }

	__inline ErrorCode AdxIrigDeviceOpenByDesc(
        IN wchar_t  const *  deviceDescription,
        IN AccessMode accessMode,
        OUT HANDLE*   deviceHandle)
    {
        //return AdxDeviceOpen(deviceNumber, accessMode, deviceHandle);


		  if (deviceDescription == 0)
		  {
			 return ErrorBufferIsNull;
		  }
		
		  wchar_t curDevDesc[256] = {0};
		  long	deviceNumber= -1;
		  long  deviceIndex = 0;
		
		  while( true )
		  {
			 ErrorCode ret = AdxDeviceGetLinkageInfo(-1, deviceIndex, &deviceNumber, curDevDesc, 0);
			 if ( deviceNumber == -1 )
			 {
				// no more device
				return ErrorDeviceNotExist;
			 }
			 if (ret == Success && wcscmp(curDevDesc, deviceDescription) == 0 )
			 {
				ret = AdxIrigDeviceOpen(deviceNumber, accessMode, deviceHandle);
				if (ret == Success)
				{
				   return ret;
				}
			 }
			 ++deviceIndex;
		  }
      
    }    
    __inline ErrorCode AdxIrigDeviceClose(IN HANDLE deviceHandle)
    {
		return GetBDaqLib()->pfnDeviceClose(deviceHandle);

	   // return AdxDeviceClose(deviceHandle);
    }
	__inline ErrorCode AdxIrigDeviceGetModuleHandle(
	   IN HANDLE     deviceHandle,
	   IN ModuleType type,
	   IN long       index,
	   OUT HANDLE*   moduleHandle )
	{
	   //return AdxDeviceGetModuleHandle(deviceHandle, type, index, moduleHandle);
	    return GetBDaqLib()->pfnDeviceGetModuleHandle(deviceHandle, type, index, moduleHandle);
	}    
	__inline ErrorCode AdxIrigDeviceTimeRead (
        IN  HANDLE deviceHandle,
        OUT PPRECISION_SYSTEMTIME precisionTime,
        OUT uint64 *reserved 
        )
    {
        //return AdxEventGetLastStatus(deviceHandle, EvtIrigInterrupt, (uint32*)precisionTime, (uint32*)reserved);
        return GetBDaqLib()->pfnEventGetLastStatus(deviceHandle, EvtIrigInterrupt, (uint32*)precisionTime, (uint32*)reserved);       
    }
	__inline ErrorCode AdxIrigDoStatusLoadingInit(
	    IN HANDLE     deviceHandle, 
	    IN long       dataLength,
	    IN void*      buffer,
	    IN long       notifyNow
	    )
	{
	   // return AdxPropertyWrite(deviceHandle, CFG_DeviceLoadingTimeInit, dataLength, buffer, notifyNow);
	   return GetBDaqLib()->pfnPropertyWrite(deviceHandle, CFG_DeviceLoadingTimeInit, dataLength, buffer, notifyNow);  
	}	
//-------------------------------------------------------
// property APIs
//-------------------------------------------------------    
    __inline ErrorCode AdxIrigPropertyRead(
        IN HANDLE          handle, 
        IN PropertyId      id, 
        IN uint32            bufferSize,
        OUT void* buffer, 
        OUT uint32* dataLength,
        OUT uint32* attribute)
    {
       // return AdxPropertyRead(handle, id, bufferSize, buffer, dataLength, attribute);
      return GetBDaqLib()->pfnPropertyRead(handle, id, bufferSize, buffer, dataLength, attribute);  
    }
    
    __inline ErrorCode AdxIrigPropertyWrite(
        IN HANDLE     handle, 
        IN PropertyId id, 
        IN uint32       dataLength,
        IN void*      buffer,
        IN uint32       notifyNow)
    {
        //return AdxPropertyWrite(handle, id, dataLength, buffer, notifyNow);
       return GetBDaqLib()->pfnPropertyWrite(handle, id, dataLength, buffer, notifyNow);  
    }
	
	//-------------------------------------------------------
	// digital input/output APIs
	//-------------------------------------------------------
	__inline ErrorCode AdxIrigDiReadPorts(
	   IN HANDLE dioHandle,
	   IN long   portStart,
	   IN long   portCount,
	   OUT uint8* dataBuffer)
	{
	   //return AdxDiReadPorts(dioHandle, portStart, portCount, dataBuffer);
	  return GetBDaqLib()->pfnDiReadPorts(dioHandle, portStart, portCount, dataBuffer); 
	}
	__inline ErrorCode AdxIrigDoWritePorts(
	   IN HANDLE dioHandle,
	   IN long   portStart,
	   IN long	 portCount,
	   IN uint8*  dataBuffer)
	{
	  // return AdxDoWritePorts(dioHandle, portStart, portCount, dataBuffer);
	  return GetBDaqLib()->pfnDoWritePorts(dioHandle, portStart, portCount, dataBuffer);
	}
	__inline ErrorCode AdxIrigDoReadBackPorts(
	   IN HANDLE dioHandle,
	   IN long   portStart,
	   IN long   portCount,
	   OUT uint8* dataBuffer)
	{
	   //return AdxDoReadBackPorts(dioHandle, portStart, portCount, dataBuffer);
	  return GetBDaqLib()->pfnDoReadBackPorts(dioHandle, portStart, portCount, dataBuffer); 
	}
	__inline ErrorCode AdxIrigDiSnapStart(
	   IN HANDLE  dioHandle,
	   IN EventId id,
	   IN long    portStart,
	   IN long    portCount,
	   OUT uint8** dataBuffer)
	{
	  // return AdxDiSnapStart(dioHandle, id, portStart, portCount, dataBuffer);
	  return GetBDaqLib()->pfnDiSnapStart(dioHandle, id, portStart, portCount, dataBuffer);
	}
	__inline ErrorCode AdxIrigDiSnapStop(
	   IN HANDLE  dioHandle,
	   IN EventId id)
	{
	   //return AdxDiSnapStop(dioHandle, id);
	   return GetBDaqLib()->pfnDiSnapStop(dioHandle, id);
	}

	__inline ErrorCode AdxIrigLedOn(
	   IN HANDLE dioHandle,
	   IN long   channelStart,
	   IN long	 channelCount)
	   
	{
	  // return AdxDoWritePorts(dioHandle, portStart, portCount, dataBuffer);
	  
	  return GetBDaqLib()->pfnLedOn(dioHandle, channelStart, channelCount);
	}

	__inline ErrorCode AdxIrigLedOff(
	   IN HANDLE dioHandle,
	   IN long   channelStart,
	   IN long	 channnelCount)
	{
	  // return AdxDoWritePorts(dioHandle, portStart, portCount, dataBuffer);
	  return GetBDaqLib()->pfnLedOff(dioHandle, channelStart, channnelCount);
	}
	
	__inline ErrorCode AdxIrigLedStatusRead(
	   IN HANDLE dioHandle,
	   IN long   portStart,
	   IN long   portCount,
	   OUT uint8* dataBuffer)
	{
	   //return AdxDoReadBackPorts(dioHandle, portStart, portCount, dataBuffer);
	  return GetBDaqLib()->pfnLedStatusRead(dioHandle, portStart, portCount, dataBuffer); 
	}	
	
	__inline ErrorCode AdxIrigWaitForMultipleObjects(
	    HANDLE dioHandle,
	    int	 count,
	    HANDLE evevts[],
	    int	 WaitAll,
	    int  timeout)
	{
	   if (InitializeBioDaqLibray(GetBDaqLib()))
       {
	   		return GetBDaqLib()->pfnWaitForMultipleObjects(dioHandle, count, evevts, WaitAll, timeout);
	   }
	   return ErrorDriverNotFound;
	}


#endif  //OS 
#if !defined(_BDAQ_NO_NAMESPACE) && defined(__cplusplus)
    } // namespace : IRIG
} // namespace : Automation
#endif

#endif	// _BIRIGTIMING_H_
