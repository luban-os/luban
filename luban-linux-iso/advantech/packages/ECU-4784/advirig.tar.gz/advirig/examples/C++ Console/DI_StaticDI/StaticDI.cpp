
/*******************************************************************************
Copyright (c) 1983-2012 Advantech Co., Ltd.
********************************************************************************
THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY INFORMATION
WHICH IS THE PROPERTY OF ADVANTECH CORP., ANY DISCLOSURE, USE, OR REPRODUCTION,
WITHOUT WRITTEN AUTHORIZATION FROM ADVANTECH CORP., IS STRICTLY PROHIBITED. 

================================================================================
REVISION HISTORY
--------------------------------------------------------------------------------
$Log:  $

--------------------------------------------------------------------------------
$NoKeywords:  $
*/
/******************************************************************************
*
* Windows Example:
*    StaticDI.cpp
*
* Example Category:
*    DIO
*
* Description:
*    This example demonstrates how to use Static DI function.
*
* Instructions for Running:
*    1. Set the 'deviceDescription' for opening the device. 
*    2. Set the 'startPort' as the first port for Di scanning.
*    3. Set the 'portCount' to decide how many sequential ports to operate Di scanning.
*
* I/O Connections Overview:
*    Please refer to your hardware reference manual.
*
******************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <wchar.h>

#include "../../../inc/compatibility.h"
#include "../../../inc/BIrigTiming.h"

using namespace Automation::IRIG;
//-----------------------------------------------------------------------------------
// Configure the following three parameters before running the demo
//-----------------------------------------------------------------------------------

int32    startPort = 0;
uint8    portCount = 1;

inline void waitAnyKey()
{
   do{SLEEP(1);} while(!kbhit());
} 

int main(int argc, char* argv[])
{
   ErrorCode        ret = Success;
   long deviceNumber = 0; 
   HANDLE deviceHandle = NULL;
   HANDLE dioHandle = NULL;
   
   do
   {

	  //
	  // Open the device with 'device number' and ModeWrite/ModeWriteWithReset mode
	  // to get the full control the device.
	  //
      printf("Please input device number:");
      scanf("%ld",&deviceNumber);

	  ret = AdxIrigDeviceOpen(deviceNumber, ModeWrite, &deviceHandle);
	  if ( BioFailed(ret) )
	  {
	   	printf("AdxIrigDeviceOpen Failed:[%08X]\n", ret);
		break;
	  }   
      // Get Dio module handle
	  ret = AdxIrigDeviceGetModuleHandle(deviceHandle, DaqDio,0, &dioHandle);
	  if ( BioFailed(ret) )
	  {
	   	printf("AdxIrigDeviceGetModuleHandle Failed:[%08X]\n", ret);
		break;
	  }   
	  ret = AdxIrigPropertyRead(dioHandle,  CFG_FeaturePortsCount, sizeof(uint32), &portCount, NULL, NULL);
	  if ( BioFailed(ret) )
	  {
	   	printf("Read CFG_FeaturePortsCount Failed:[%08X]\n", ret);
		break;
	  }   
      // Step 3: Read DI ports' status and show.
      printf(" Reading ports' status is in progress, any key to quit !\n\n");
      uint8  bufferForReading[64] = {0};//the first element of this array is used for start port
      do
      {
         ret = AdxIrigDiReadPorts(dioHandle,startPort,portCount,bufferForReading);
		 if ( BioFailed(ret) )
		 {
		   printf("AdxIrigDiReadPorts Failed:[%08X]\n", ret);
		   break;
		 }	 
         //Show ports' status
         for ( int32 i = startPort;i < startPort+portCount; ++i)
         {
            printf(" DI port %d status is: 0x%X\n\n", i, bufferForReading[i-startPort]);
         }
         SLEEP(1);
      }while(!kbhit());

   }while(false);

	// Step 4: Close device and release any allocated resource.
	if(deviceHandle != NULL)
	{
		AdxIrigDeviceClose(deviceHandle);
		deviceHandle = NULL;
	}

	// If something wrong in this execution, print the error code on screen for tracking.
   if(BioFailed(ret))
   {
      printf(" Some error occurred. And the last error code is Ox%X.\n", ret);
      waitAnyKey();
   }
   return 0;
}
