/*******************************************************************************
Copyright (c) 1983-2012 Advantech Co., Ltd.
********************************************************************************
THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY INFORMATION
WHICH IS THE PROPERTY OF ADVANTECH CORP., ANY DISCLOSURE, USE, OR REPRODUCTION,
WITHOUT WRITTEN AUTHORIZATION FROM ADVANTECH CORP., IS STRICTLY PROHIBITED. 

================================================================================
REVISION HISTORY
--------------------------------------------------------------------------------
$Log:  $

--------------------------------------------------------------------------------
$NoKeywords:  $
*/

/******************************************************************************
*
* Example:
*    DIInterrupt.cpp
*
* Example Category:
*    DIO
*
* Description:
*    This example demonstrates how to use DI snap function with a channel interrupt event
*
* Instructions for Running:
*    1. Set the 'deviceDescription' for opening the device. 
*    2. Set the 'startPort' as the first port for Di scanning.
*    3. Set the 'portCount' to decide how many sequential ports to operate Di scanning.

* I/O Connections Overview:
*    Please refer to your hardware reference manual.
*
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <sys/time.h>
#include <pthread.h>
#include <assert.h>
#include <signal.h>
#include <wchar.h>

#include "../../../../inc/compatibility.h"
#include "../../../../inc/BIrigTiming.h"
using namespace Automation::IRIG;
//-----------------------------------------------------------------------------------
// Configure the following three parameters before running the demo
//-----------------------------------------------------------------------------------
int32    startPort = 0;   
int32    portCount = 1;   
#define WAIT_TIMEOUT 258
#define description L"PCI-IRIG, BID#0"

//function declaration
long     GetFirstValidInterruptEventHandle(HANDLE , uint32&, EventId &, HANDLE &);

int main(int argc, char* argv[])
{
	ErrorCode		 ret = Success;
	int rtl = 0;
	long deviceNumber = 0; 
	HANDLE deviceHandle = NULL;
	HANDLE dioHandle = NULL;
    EventId      eventId;
    HANDLE       eventHandle = NULL;
	uint8 trig_edge[8] = {0};
	uint32 size=0;
    uint32  m_iSize = 0;
   
	int dwWait = 0;
	int delayTime = 0;
    struct timespec ts;
	
	do
	{
	
	   //
	   // Open the device with 'device number' and ModeWrite/ModeWriteWithReset mode
	   // to get the full control the device.
	   //
	   ret = AdxIrigDeviceOpenByDesc(description, ModeWrite, &deviceHandle);
	   if ( BioFailed(ret) )
	   {
		 printf("AdxIrigDeviceOpen Failed:[%08X]\n", ret);
		 break;
	   }   
	   // Get Dio module handle
	   ret = AdxIrigDeviceGetModuleHandle(deviceHandle, DaqDio,0, &dioHandle);
	   if ( BioFailed(ret) )
	   {
		 printf("AdxIrigDeviceGetModuleHandle Failed:[%08X]\n", ret);
		 break;
	   }   


	   ret = AdxIrigEventGetHandle(dioHandle, EvtDiintChannel000,&eventHandle );
	   if ( BioFailed(ret) )
	   {
		 printf("AdxIrigDeviceGetModuleHandle Failed:[%08X]\n", ret);
		 break;
	   }   
	   if(NULL == eventHandle)
	   {
		  printf("The device doesn't support DI channel interrupt!\n");
		  throw ret;
	   }

	   // clear the event flag once after we call AdxIrigEventGetHandle to initialize.
	   AdxIrigEventClearFlag(dioHandle, EvtDiintChannel000, 0, 0);

	   // Step 3: get notification event handle of a DI channel. 
	   // In this demo, we are using the first available one.
	   uint32 	channelUsed = 0;
	   GetFirstValidInterruptEventHandle( dioHandle,channelUsed,eventId,eventHandle);
	   if(NULL == eventHandle)
	   {
		  printf("The device doesn't support DI channel interrupt!\n");
		  throw ret;
	   }
	   printf("DI channel %d is used to detect interrupt!\n\n", channelUsed);
	  


	   ret = AdxIrigPropertyRead(dioHandle, 
			   CFG_DiintTriggerEdgeOfChannels, 
			   sizeof(trig_edge), trig_edge, 
			   &size, NULL);
	   //
	   // This is a sample to show how to handle error code returned by AdxPropertyXxx.
	   // The error code handler will not be shown below.
	   //
	   if ( BioFailed(ret) )
	   {
		   printf("AdxIrigPropertyRead(CFG_DiintTriggerEdgeOfChannels) Failed:[%08X]\n", ret);
		   break;
	   }
	   for (long i=0;i<(long)(size/sizeof(uint8));i++)
	   {
		   printf("%u\t",trig_edge[i]);
	   }


	   m_iSize=size/sizeof(uint8);

       //If the old edge if rising, change it to falling edge,  and vice versa. 
	   printf("\nChange DiintTriggerEdgeOfChannels value");
	   for(long i=0;i<m_iSize;i++)
       {
           if(trig_edge[i] == 1)
               trig_edge[i] = 2;
           else if(trig_edge[i] == 2)
               trig_edge[i] = 1;
       }
		  
	   ret=AdxIrigPropertyWrite(dioHandle,CFG_DiintTriggerEdgeOfChannels,m_iSize*sizeof(uint8),trig_edge,0);
	   if(BioFailed(ret))
	   {
		   printf("PropertyWrite Error, And the error code is Ox%X.\n", ret);
		   break;
	   }
	   
	   printf("\nReadback value:");
	   ret=AdxIrigPropertyRead(dioHandle,CFG_DiintTriggerEdgeOfChannels,sizeof(trig_edge),trig_edge,&size,NULL);
	   if(BioFailed(ret))
	   {
		   printf("AdxIrigPropertyRead (CFG_DiintTriggerEdgeOfChannels) Failed:[%08X]\n", ret);
		   break;
	   }

	   for (long i=0;i<(long)(size/sizeof(uint8));i++)
	   {
		   printf("%u\t",trig_edge[i]);
	   }

   
	   // Step 4: start Di snap
	   // The first parameter specify the event id to snap, in this demo it is 'EvtDiintChannelxxx';
	   // The second and third specify the DI port range to be snapped when the specified event occurred.
	   // The fourth parameter is a variable that receives the base address of snapped data cache.
	   uint8 * bufferForSnap = NULL;
	   ret = AdxIrigDiSnapStart( dioHandle,EvtDiintChannel000,startPort,portCount,&bufferForSnap );
	   if(BioFailed(ret))
	   {
		  throw ret;
	   }
	
	   // Step 5: wait for the event for interrupt and show snapped data, 
	   printf("\nSnap has started, press any key to stop it!\n");
	   
	    do
	   {	
  
		  delayTime = 1000;
	      //dwWait = WaitForSingleObject( *(unsigned int *)eventHandle,delayTime);

		 dwWait = AdxIrigWaitForMultipleObjects(dioHandle, 1,&eventHandle,false,delayTime);          
		  if(!dwWait)
		  {
			 printf("DI channel interrupt occurred!\n");
	
			 //show snap data.
			 for ( uint32 i = startPort;i < startPort + portCount; ++i )
			 {
				printf("DI port %d status is:  0x%X\n\n", i, bufferForSnap[i-startPort]);
			 }
			 //clear the event status, otherwise the device will not signal this event again.
			 ret= AdxIrigEventClearFlag(dioHandle, EvtDiintChannel000,0,0);
			 if ( BioFailed(ret))
			{
					printf("AdxIrigEventClearFlag Failed:[%08X]\n", ret);
					break;
			}			 
		  }
		  else if ( WAIT_TIMEOUT == dwWait )
		  {
				printf("Wait timeout.\n");
		  }
		  else if (WAIT_FAILED == dwWait   )
		  {
            continue;
          }
		  else
		  {
				printf("WaitForSingleObject Failed\n");
				break;
		  }
	   }while (!kbhit());
	}while (0);
	
	// Close device and release any allocated resource.
	if(( dioHandle!= NULL) && (eventHandle != NULL))
	{
	   AdxIrigDiSnapStop(dioHandle, EvtDiintChannel000 ); 
	}
	if(deviceHandle!= NULL)
	{
	   AdxIrigDeviceClose(deviceHandle);
	}
	return 0;

}

//get handle of a DI channel interrupt event***************************************************************
long  GetFirstValidInterruptEventHandle( HANDLE dioHandle,uint32 & channelNumber,EventId & eventType,HANDLE & eventHandle)  // reference use,need testing!
{
   uint32     featureDiSnapEventSources[400] = {0};

   uint32     result = 0;

   result = AdxIrigPropertyRead(dioHandle, CFG_FeatureDiSnapEventSources,400,featureDiSnapEventSources,NULL, NULL );
   if(BioFailed(result))
   {
      return result;
   }
   //AdxIrigEventGetHandle(dioHandle,eventType,&eventHandle);
   for(uint32 i = 0; i < 4; ++i)
   {
      if((featureDiSnapEventSources[i] >= EvtDiintChannel000)
         && (featureDiSnapEventSources[i] <= EvtDiintChannel003))
      {
         result = AdxIrigEventGetHandle(dioHandle, (EventId)featureDiSnapEventSources[i],&eventHandle );
         if(BioFailed(result))
         {
            return result;
         }
         channelNumber = featureDiSnapEventSources[i] - EvtDiintChannel000;
         eventType = (EventId)featureDiSnapEventSources[i];
		 
		 AdxIrigEventClearFlag(dioHandle, (EventId)featureDiSnapEventSources[i], 0, 0);		
         return result;
      }
   }
   return result;
}  


