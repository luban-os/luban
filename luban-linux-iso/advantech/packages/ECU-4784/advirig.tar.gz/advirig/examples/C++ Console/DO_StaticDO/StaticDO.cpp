/*******************************************************************************
Copyright (c) 1983-2012 Advantech Co., Ltd.
********************************************************************************
THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY INFORMATION
WHICH IS THE PROPERTY OF ADVANTECH CORP., ANY DISCLOSURE, USE, OR REPRODUCTION,
WITHOUT WRITTEN AUTHORIZATION FROM ADVANTECH CORP., IS STRICTLY PROHIBITED. 

================================================================================
REVISION HISTORY
--------------------------------------------------------------------------------
$Log:  $

--------------------------------------------------------------------------------
$NoKeywords:  $
*/

/******************************************************************************
*
* Windows Example:
*    StaticDO.cpp
*
* Example Category:
*    DIO
*
* Description:
*    This example demonstrates how to use Static DO function.
*
* Instructions for Running:
*    1. Set the 'deviceDescription' for opening the device. 
*    2. Set the 'startPort'as the first port for Do .
*    3. Set the 'portCount'to decide how many sequential ports to operate Do.
*
* I/O Connections Overview:
*    Please refer to your hardware reference manual.
*
******************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <wchar.h>

#include "../../../inc/compatibility.h"
#include "../../../inc/BIrigTiming.h"
using namespace Automation::IRIG;
//-----------------------------------------------------------------------------------
// Configure the following three parameters before running the demo
//-----------------------------------------------------------------------------------
int32    startPort = 0;
int32    portCount = 1;

inline void waitAnyKey()
{
   do{SLEEP(1);} while(!kbhit());
} 

int main(int argc, char* argv[])
{
	ErrorCode		 ret = Success;
	long deviceNumber = 0; 
	HANDLE deviceHandle = NULL;
	HANDLE dioHandle = NULL;
   do
   {
	  //
	  // Open the device with 'device number' and ModeWrite/ModeWriteWithReset mode
	  // to get the full control the device.
	  //
       printf("Please input device number:");
       scanf("%ld",&deviceNumber);

	  ret = AdxIrigDeviceOpen(deviceNumber, ModeWrite, &deviceHandle);
	  if ( BioFailed(ret) )
	  {
		 printf("AdxIrigDeviceOpen Failed:[%08X]\n", ret);
		 break;
	  }   
	  
	  // Get Dio module handle
	  ret = AdxIrigDeviceGetModuleHandle(deviceHandle, DaqDio,0, &dioHandle);
	  if ( BioFailed(ret) )
	  {
		 printf("AdxIrigDeviceGetModuleHandle Failed:[%08X]\n", ret);
		 break;
	  }   
	   
      // Step 3: Write DO ports
      printf("Please input DO port count:");
      scanf("%ld",&portCount);

      uint8  bufferForWriting[64] = {0};//the first element is used for start port
      for ( int32 i = startPort;i < portCount + startPort; ++i)
      {
         printf(" Input a 16 hex number for DO port %d to output(for example, 0x00): ", i);
         scanf("%x", (int*)&bufferForWriting[i-startPort]);
      }
      ret = AdxIrigDoWritePorts(dioHandle,startPort,portCount,bufferForWriting );
	  if ( BioFailed(ret) )
	  {
		 printf("AdxIrigDoWritePorts Failed:[%08X]\n", ret);
		 break;
	  }   

      printf("\n DO output completed !\n");

      // Read back the DO status. 
      // Note: 
      // For relay output, the read back must be deferred until the relay is stable.
      // The delay time is decided by the HW SPEC.
      uint8 bufferForReading[64] = {0};
      ret = AdxIrigDoReadBackPorts( dioHandle,startPort,portCount,bufferForReading );
	  if ( BioFailed(ret) )
	  {
		 printf("AdxIrigDoReadBackPorts Failed:[%08X]\n", ret);
		 break;
	  }   

      // Show DO ports' status
       for ( int32 i = startPort;i < portCount + startPort; ++i)
      {
          printf("Now, DO port %d status is:  0x%x\n\n", i, bufferForReading[i-startPort]);
      }
   }while(false);

    // Step 4: Close device and release any allocated resource.
	if(deviceHandle != NULL)
	{
		AdxIrigDeviceClose(deviceHandle);
		deviceHandle = NULL;
	}

	// If something wrong in this execution, print the error code on screen for tracking.
   if(BioFailed(ret))
   {
      printf(" Some error occurred. And the last error code is Ox%X.\n", ret);
      waitAnyKey();
   }
   waitAnyKey();
   return 0;
}
