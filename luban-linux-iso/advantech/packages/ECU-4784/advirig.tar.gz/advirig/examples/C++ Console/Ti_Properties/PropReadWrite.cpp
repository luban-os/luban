/*******************************************************************************
Copyright (c) 1983-2012 Advantech Co., Ltd.
********************************************************************************
THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY INFORMATION
WHICH IS THE PROPERTY OF ADVANTECH CORP., ANY DISCLOSURE, USE, OR REPRODUCTION,
WITHOUT WRITTEN AUTHORIZATION FROM ADVANTECH CORP., IS STRICTLY PROHIBITED. 

================================================================================
REVISION HISTORY
--------------------------------------------------------------------------------
$Log:  $
--------------------------------------------------------------------------------
$NoKeywords:  $
*/
/******************************************************************************
*
* Windows Example:
*    PropReadWrite.cpp
*
* Example Category:
*    Timing
*
* Description:
*    This example demonstrates how to get/set properties of this device
*
* Instructions for Running:
*    1. Set the 'deviceNumber' for opening the device.
*    2. Call AdxPropertyRead/AdxPropertyWrite with propertyIDs listed below.
*           CFG_DeviceTimingSourceType
*           CFG_DeviceTimingSourceConnected
*           CFG_DeviceTimingEnabled
*
* I/O Connections Overview:
*    Please refer to your hardware reference manual.
*
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
//#include <conio.h>

#include "../../../inc/BIrigTiming.h"
#include "../../../inc/compatibility.h"
using namespace Automation::IRIG;

int main(int argc, char* argv[])
{
    //
    // !!! Before running,
    // modify this value according to the configuration dialog of this device.
    //
    long deviceNumber = 0; 
    
    //
    //
    HANDLE deviceHandle = NULL;
    ErrorCode errorCode = Success;
    long   oldSrcType, oldTimingEn;
    long   srcType, srcCnn, timingEn;
    long   prop = 0;

    do 
    {
        //
        // Open the device with 'device number' and ModeWrite/ModeWriteWithReset mode
        // to get the full control the device.
        //
        errorCode = AdxIrigDeviceOpen(deviceNumber, ModeWrite, &deviceHandle);
        if ( BioFailed(errorCode) )
        {
            printf("AdxIrigDeviceOpen Failed:[%08X]\n", errorCode);
            break;
        }

        //
        // Get the value of current properties.
        // We will restore them at the end of this sample code.
        //
        errorCode = AdxIrigPropertyRead(deviceHandle, 
            CFG_DeviceTimingSourceType, 
            sizeof(oldSrcType), &oldSrcType, 
            NULL, NULL);
        //
        // This is a sample to show how to handle error code returned by AdxPropertyXxx.
        // The error code handler will not be shown below.
        //
        if ( BioFailed(errorCode) )
        {
            printf("AdxIrigPropertyRead(CFG_DeviceTimingSourceType) Failed:[%08X]\n", errorCode);
            break;
        }

        AdxIrigPropertyRead(deviceHandle, 
            CFG_DeviceTimingEnabled, 
            sizeof(oldTimingEn), &oldTimingEn, 
            NULL, NULL);


        //
        // Disable timing to change properties.
        // 
        timingEn = 0;
        AdxIrigPropertyWrite(deviceHandle, 
            CFG_DeviceTimingEnabled, 
            sizeof(timingEn), &timingEn, 
            0);

        //
        // set new properties value.
        //
        srcType = LocalTime; // or, srcType = LocalTime;

        if ( UtcTime == srcType )
        {
            printf("Write CFG_DeviceTimingSourceType = UtcTime.\n");
        }
        else if ( LocalTime == srcType )
        {
            printf("Write CFG_DeviceTimingSourceType = LocalTime.\n");
        }

        AdxIrigPropertyWrite(deviceHandle, 
            CFG_DeviceTimingSourceType, 
            sizeof(srcType), &srcType, 
            0);

        // read back
        AdxIrigPropertyRead(deviceHandle, 
            CFG_DeviceTimingSourceType, 
            sizeof(srcType), &srcType, 
            NULL, NULL);

        if ( UtcTime == srcType )
        {
            printf("Read CFG_DeviceTimingSourceType = UtcTime.\n");
        }
        else if ( LocalTime == srcType )
        {
            printf("Read CFG_DeviceTimingSourceType = LocalTime.\n");
        }

        //
        // We read CFG_DeviceTimingSourceConnected property repetitively 
        // to check connection state of the external timing source.
        //
        AdxIrigPropertyRead(deviceHandle, 
            CFG_DeviceTimingSourceConnected, 
            sizeof(srcCnn), &srcCnn, 
            NULL, NULL);
        if ( srcCnn )
        {
            printf("\n External Timing Source is Connected.\n");
        }
        else
        {
            printf("\n External Timing Source is not Connected.\n");
        }

        prop = srcCnn;

        while (!kbhit())
        {
            AdxIrigPropertyRead(deviceHandle, 
                CFG_DeviceTimingSourceConnected, 
                sizeof(srcCnn), &srcCnn, 
                NULL, NULL);

            if ( srcCnn != prop )
            {
                if ( srcCnn )
                {
                    printf("\n External Timing Source is Connected.\n");
                }
                else
                {
                    printf("\n External Timing Source is not Connected.\n");
                }
                prop = srcCnn;
            }

            SLEEP(1);
        }


        //
        // restore the previous settings.
        //
        AdxIrigPropertyWrite(deviceHandle, 
            CFG_DeviceTimingSourceType, 
            sizeof(oldSrcType), &oldSrcType, 
            0);
        AdxIrigPropertyWrite(deviceHandle, 
            CFG_DeviceTimingEnabled, 
            sizeof(oldTimingEn), &oldTimingEn, 
            0);


    } while (0);



    // Close device and release any allocated resource.
    if(deviceHandle != NULL)
    {
        AdxIrigDeviceClose(deviceHandle);
        deviceHandle = NULL;
    }

    return 0;
}