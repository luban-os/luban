/*******************************************************************************
Copyright (c) 1983-2012 Advantech Co., Ltd.
********************************************************************************
THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY INFORMATION
WHICH IS THE PROPERTY OF ADVANTECH CORP., ANY DISCLOSURE, USE, OR REPRODUCTION,
WITHOUT WRITTEN AUTHORIZATION FROM ADVANTECH CORP., IS STRICTLY PROHIBITED. 

================================================================================
REVISION HISTORY
--------------------------------------------------------------------------------
$Log:  $
--------------------------------------------------------------------------------
$NoKeywords:  $
*/
/******************************************************************************
*
* Windows Example:
*    TimingWithoutEvent.cpp
*
* Example Category:
*    Timing
*
* Description:
*    This example demonstrates how to get precision date/time from our device 
*    without timing event.
*
* Instructions for Running:
*    1. Set the 'deviceNumber' for opening the device.
*    2. Call AdxDeviceTimeRead repetitively to get current date/time.
*
* I/O Connections Overview:
*    Please refer to your hardware reference manual.
*
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "../../../inc/BIrigTiming.h"
#include "../../../inc/compatibility.h"
using namespace Automation::IRIG;

int main(int argc, char* argv[])
{
    //
    // !!! Before running,
    // modify this value according to the configuration dialog of this device.
    //
    long deviceNumber = 0; 


    //
    //
    HANDLE deviceHandle = NULL;
    ErrorCode errorCode = Success;
    PRECISION_SYSTEMTIME dateTime;

    do 
    {
        //
        // Open the device with 'device number' and ModeWrite/ModeWriteWithReset mode
        // to get the full control the device.
        //
        errorCode = AdxIrigDeviceOpen(deviceNumber, ModeWrite, &deviceHandle);
        if ( BioFailed(errorCode) )
        {
            printf("AdxIrigDeviceOpen Failed:[%08X]\n", errorCode);
            break;
        }

        //
        // We read date/time repetitively until a key is hit in the keyboard.
        //
        while (!kbhit())
        {

            errorCode = AdxIrigDeviceTimeRead(deviceHandle, &dateTime, NULL);
            if ( BioFailed(errorCode))
            {
                printf("\nAdxIrigDeviceTimeRead Failed:[%08X]\n", errorCode);
                break;
            }

            printf("\nCurrent Time:\n");
            printf(" %04ld - %02ld - %02ld, Weekday = %ld\n", 
                dateTime.Year, dateTime.Month, dateTime.Day, dateTime.DayOfWeek);
            printf(" %02ld:%02ld:%02ld, %ld us\n", 
                dateTime.Hour, dateTime.Minute, dateTime.Second, dateTime.Microseconds);

            SLEEP(1);
        }

    } while (0);



    // Close device and release any allocated resource.
    if(deviceHandle != NULL)
    {
        AdxIrigDeviceClose(deviceHandle);
        deviceHandle = NULL;
    }

    return 0;
}