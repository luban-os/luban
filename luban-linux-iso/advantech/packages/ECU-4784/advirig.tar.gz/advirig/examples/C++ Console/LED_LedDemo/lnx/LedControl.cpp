/*******************************************************************************
Copyright (c) 1983-2014 Advantech Co., Ltd.
********************************************************************************
THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY INFORMATION
WHICH IS THE PROPERTY OF ADVANTECH CORP., ANY DISCLOSURE, USE, OR REPRODUCTION,
WITHOUT WRITTEN AUTHORIZATION FROM ADVANTECH CORP., IS STRICTLY PROHIBITED. 

================================================================================
REVISION HISTORY
--------------------------------------------------------------------------------
$Log:  $

--------------------------------------------------------------------------------
$NoKeywords:  $
*/

/******************************************************************************
*
* Example:
*    LedControl.cpp
*
* Example Category:
*    LED
*
* Description:
*    This example demonstrates how to use LED function.
*

******************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <wchar.h>

#include "../../../../inc/compatibility.h"
#include "../../../../inc/BIrigTiming.h"
using namespace Automation::IRIG;

#define description L"PCI-IRIG, BID#0"

inline void waitAnyKey()
{
   do{SLEEP(1);} while(!kbhit());
} 

int main(int argc, char* argv[])
{
    ErrorCode ret = Success;
    long   deviceNumber = 0; 
    HANDLE deviceHandle = NULL;
    HANDLE ledHandle = NULL;


    // initializing
    do
    {
        //
        // Open the device with 'device number' and ModeWrite/ModeWriteWithReset mode
        // to get the full control the device.
        //
        ret = AdxIrigDeviceOpenByDesc(description, ModeWrite, &deviceHandle);
        if ( BioFailed(ret) )
        {
            printf("AdxIrigDeviceOpen Failed:[%08X]\n", ret);
            break;
        }   

        // Get Dio module handle
        ret = AdxIrigDeviceGetModuleHandle(deviceHandle, DaqDio, 0, &ledHandle);
        if ( BioFailed(ret) )
        {
            printf("AdxIrigDeviceGetModuleHandle Failed:[%08X]\n", ret);
            break;
        }   
    } while (false);

    // If something wrong in this execution, print the error code on screen for tracking.
    if(BioFailed(ret))
    {
        printf(" Some error occurred. And the last error code is Ox%X.\n", ret);
        waitAnyKey();
    }

    //
    // Initializing succeed
    // Start LED On-off looping, press any key to exit
    //
    else
    {
        
        printf("Start LED lightening... \n");
        uint8 LedStatus[2] = {0}; 
        int   i = 0;
		
        while (!kbhit())
        {
            // each bit of LedStatus relates to a LED channel
            // set LED channel[i] to 1 (ON) while others are set to 0 (OFF).

			AdxIrigLedOn(ledHandle, 0, 8); 
			sleep(1);
			
			AdxIrigLedOff(ledHandle, 0, 8); 	
			sleep(1);

			for(i = 0;i< 8;i = i + 2)
            {
		
				// write LED status to device. 

				AdxIrigLedOn(ledHandle, i, 2);	
				AdxIrigLedStatusRead(ledHandle, 0, 2,LedStatus);				
				printf("LED status: %02X  %02X\n", LedStatus[0],LedStatus[1]);							
				sleep(1);
				
				AdxIrigLedOff(ledHandle, i, 2);	
				AdxIrigLedStatusRead(ledHandle, 0, 2,LedStatus);				
				printf("LED status: %02X  %02X\n", LedStatus[0],LedStatus[1]);				
				sleep(1);

			}


        }

		AdxIrigLedOff(ledHandle, 0, 8);	

    }

    // Close device and release any allocated resource.
    if(deviceHandle != NULL)
    {
        AdxIrigDeviceClose(deviceHandle);
        deviceHandle = NULL;
    }

    printf("Press any key to exit... \n");
    waitAnyKey();
    return 0;
}
