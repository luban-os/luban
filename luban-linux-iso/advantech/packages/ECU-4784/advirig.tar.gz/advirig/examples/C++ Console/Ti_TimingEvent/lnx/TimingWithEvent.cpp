/*******************************************************************************
  Copyright (c) 1983-2012 Advantech Co., Ltd.
 ********************************************************************************
 THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY INFORMATION
 WHICH IS THE PROPERTY OF ADVANTECH CORP., ANY DISCLOSURE, USE, OR REPRODUCTION,
 WITHOUT WRITTEN AUTHORIZATION FROM ADVANTECH CORP., IS STRICTLY PROHIBITED. 

 ================================================================================
 REVISION HISTORY
 --------------------------------------------------------------------------------
 $Log:  $
 --------------------------------------------------------------------------------
 $NoKeywords:  $
 */
/******************************************************************************
 *
 * Windows Example:
 *    TimingWithEvent.cpp
 *
 * Example Category:
 *    Timing
 *
 * Description:
 *    This example demonstrates how to get precision date/time from our device 
 *    with timing event.
 *
 * Instructions for Running:
 *    1. Set the 'deviceNumber' for opening the device.
 *    2. Get the handle of 'EvtTimingInterrupt' and wait it.
 *    3. Call AdxDeviceTimeRead to get current date/time when EvtTimingInterrupt is signaled.
 *
 * I/O Connections Overview:
 *    Please refer to your hardware reference manual.
 *
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <sys/time.h>
#include <wchar.h>

#include "../../../../inc/BIrigTiming.h"

#include "../../../../inc/compatibility.h"

using namespace Automation::IRIG;

#define DISABLEINTERRUPT 0
#define ENABLEINTERRUPT  1

#define WAIT_TIMEOUT 258
#define eventCount 2
#define description L"PCI-IRIG, BID#0"

//#define EvtIrigInterrupt EvtDiintChannel000

static int WaitForSingleObject(int fd, int timeoutSec)
{
	fd_set evt_set;
	struct timeval tv_val;
	int ret;

	FD_ZERO(&evt_set);
	FD_SET(fd, &evt_set);

	memset(&tv_val, 0, sizeof(tv_val));
	tv_val.tv_sec = timeoutSec;

	ret = select(fd + 1, &evt_set, NULL, NULL, &tv_val);
	if (ret == 0) {
		return WAIT_TIMEOUT;
	} else if (ret < 0) {	/* something is wrong */
		return -1;
	} else {
		return 0;
	}
}

int main(int argc, char* argv[])
{
	//
	// !!! Before running,
	// modify this value according to the configuration dialog of this device.
	//
	long deviceNumber = 0; 

	//
	//
	HANDLE deviceHandle = NULL;
	HANDLE eventHandle  = NULL;
	ErrorCode errorCode = Success;
	PRECISION_SYSTEMTIME dateTime;
	int dwWait = 0;
	int delayTime = 0;
	int oldStatus = 0;
	int newStatus = 0;

	do 
	{
		//
		// Open the device with 'device number' and ModeWrite/ModeWriteWithReset mode
		// to get the full control the device.
		//
		errorCode = AdxIrigDeviceOpenByDesc(description, ModeWrite, &deviceHandle);
	//	errorCode = AdxIrigDeviceOpen(0, ModeWrite, &deviceHandle);
		if ( BioFailed(errorCode) )
		{
			printf("AdxIrigDeviceOpen Failed:[%08X]\n", errorCode);
			break;
		}

		errorCode = AdxIrigPropertyRead(deviceHandle, 
				CFG_DeviceTimingEnabled, 
				sizeof(oldStatus), &oldStatus, 
				NULL, NULL);

		if (DISABLEINTERRUPT == oldStatus){
			newStatus = ENABLEINTERRUPT;
			AdxIrigPropertyWrite(deviceHandle, 
					CFG_DeviceTimingEnabled, 
					sizeof(newStatus), &newStatus, 
					0);
		}

		//
		// Get the handle of EvtTimingInterrupt.
		//
		errorCode = AdxIrigEventGetHandle(deviceHandle, EvtIrigInterrupt, &eventHandle);
		if ( BioFailed(errorCode))
		{
			printf("AdxIrigEventGetHandle Failed:[%08X]\n", errorCode);
			break;
		}

		// clear the event flag once after we call AdxIrigEventGetHandle to initialize.
		AdxIrigEventClearFlag(deviceHandle, EvtIrigInterrupt, 0, 0);

		//
		// We read date/time repetitively until a key is hit in the keyboard.
		//
		while (!kbhit())
		{
			printf("\n");

			// IRIG-B will generate a timing interrupt event per second.
			delayTime = 2;  //Second
			dwWait = WaitForSingleObject(*(unsigned int *)eventHandle, delayTime);

			if(!dwWait)
			{
				printf("Timing Event arrival:\n");

				// read date/time from the device.
				errorCode = AdxIrigDeviceTimeRead(deviceHandle, &dateTime, NULL);
				if ( BioFailed(errorCode))
				{
					printf("AdxIrigDeviceTimeRead Failed:[%08X]\n", errorCode);
					break;
				}

				printf("Current Time:\n");
				printf(" %04ld - %02ld - %02ld, Weekday = %ld\n", 
						dateTime.Year, dateTime.Month, dateTime.Day, dateTime.DayOfWeek);
				printf(" %02ld:%02ld:%02ld, %lu us\n", 
						dateTime.Hour, dateTime.Minute, dateTime.Second, dateTime.Microseconds);

				// 
				// we should call AdxIrigEventClearFlag after each time we receive the event.
				errorCode = AdxIrigEventClearFlag(deviceHandle, EvtIrigInterrupt, 0, 0);
				if ( BioFailed(errorCode))
				{
					printf("AdxIrigEventClearFlag Failed:[%08X]\n", errorCode);
					break;
				}
			}
			else if ( WAIT_TIMEOUT == dwWait )
			{
				printf("Wait timeout.\n");
			}
			else
			{
				printf("WaitForSingleObject Failed\n");
				break;
			}
		}

	} while (0);

	// Close device and release any allocated resource.
	if(deviceHandle != NULL)
	{
		AdxIrigDeviceClose(deviceHandle);
		deviceHandle = NULL;
	}
	return 0;
}
