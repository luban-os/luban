#!/bin/bash

mode=$1
index=$2
value=$3

di=(451 453 454 455 456 457 458 452)
do=(459 460 461 462 463 464 465 466)

if [ "$mode"x = "-r"x ]

then
	echo di$index value:
	cat /sys/class/gpio/gpio${di[$index]}/value
	echo do$index value:
	cat /sys/class/gpio/gpio${do[$index]}/value

elif [ "$mode"x = "-w"x ]

then
	echo $value > /sys/class/gpio/gpio${do[$index]}/value

	echo di$index value:
	cat /sys/class/gpio/gpio${di[$index]}/value
	echo do$index value:
	cat /sys/class/gpio/gpio${do[$index]}/value

fi
