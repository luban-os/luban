#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <poll.h>
#include <string.h>

static int gpio_pin[8] = {451,453,454,455,456,457,458,452};

static void usage(char *filename)
{
    printf("\nUsage: %s [OPTIONS1] [OPTIONS2]\n\n", filename);
    printf("OPTIONS1 : Pin number [0-7]\n");
    printf("0-->gpio451\n");
    printf("1-->gpio453\n");
    printf("2-->gpio454\n");
    printf("3-->gpio455\n");
    printf("4-->gpio456\n");
    printf("5-->gpio457\n");
    printf("6-->gpio458\n");
    printf("7-->gpio452\n\n");
    printf("OPTIONS2 : Interrupt triggering mode [0-3]\n");
    printf("0-->none : The pin is an input pin, not an interrupt pin\n");
    printf("1-->rising: Pin for interrupt input, rising edge triggered\n");
    printf("2-->falling: Pin for interrupt input, falling edge triggered\n");
    printf("3-->both : Pin for interrupt input, edge trigger\n\n");
    printf("for example: %s 0 3 is reading gpio451's rising and falling interrupt\n\n", filename);
}

// none : The pin is an input pin, not an interrupt pin

// rising: Pin for interrupt input, rising edge triggered

// falling : Pin for interrupt input, falling edge triggered

// both : Pin for interrupt input, edge trigger

// 0-->none, 1-->rising, 2-->falling, 3-->both

static int gpio_edge(int pin, int edge)
{
    const char dir_str[] = "none\0rising\0falling\0both";
    char index;
    char path[64];
    int fd;

    switch(edge){

    case 0:

        index = 0;

        break;

    case 1:

        index = 5;

        break;

    case 2:

        index = 12;

        break;

    case 3:

        index = 20;

        break;

    default:

        index = 0;

        break;
    }

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/edge", pin);

    fd = open(path, O_WRONLY);

    if (fd < 0) {

        perror("Failed to open gpio edge for writing!\n");

        return -1;

    }

    if (write(fd, &dir_str[index], strlen(&dir_str[index])) < 0) {

        perror("Failed to set edge!\n");

        return -1;

    }

    close(fd);

    return 0;
}

int main(int argc,char* argv[])
{
    int fd, ret, index, pin, edge;
    struct pollfd fdset;
    char buff[10];
    char path[64];

    if (argc < 2) {

        usage(argv[0]);

        return 0;

    }

    index = atoi(argv[1]);
    pin = gpio_pin[index];

    edge = atoi(argv[2]);

    gpio_edge(pin, edge);

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", pin);

    fd = open(path, O_RDONLY);

    if(fd < 0){

        perror("Failed to open value!\n");

        return -1;

    }

    fdset.fd = fd;

    fdset.events  = POLLPRI;

    ret = read(fd, buff, 10);

    if( ret == -1 )

        perror("read()");

    while(1){

        ret = poll(&fdset,1,0);

        if( ret == -1 )

            perror("poll()");

        if(fdset.revents & POLLPRI){

            ret = lseek(fd, 0, SEEK_SET);

        if( ret == -1 )

            perror("lseek()");

        ret = read(fd, buff, 10);

        if( ret == -1 )

            perror("read()");

        else

            printf("gpio%d interrupt, value = 0x%x\n", pin, buff[0]);
        }

        usleep(100000);
    }

    return 0;
}
