#!/bin/sh

read -p "Enter Wifi SSID Name: " ssid
echo "\n \033[32m The WIFI SSID is $ssid \033[0m \n"

read -p "Enter the password of SSID:" passwd
echo "\n \033[32m The Password is $passwd \033[0m\n"

echo "\n \033[32m This will take a few seconds, so please be patient! \033[0m\n"

#interface=`fconfig | awk -F'[ :]+' '!NF{if(eth!=""&&ip=="")print eth;eth=ip4=""}/^[^ ]/{eth=$1}/inet addr:/{ip=$4}' | awk '/^w/'`

interface=`cat /proc/net/dev | awk '/^w/' | awk -F ':' '{print $1}'`

nmcli device wifi connect $ssid password $passwd ifname $interface
