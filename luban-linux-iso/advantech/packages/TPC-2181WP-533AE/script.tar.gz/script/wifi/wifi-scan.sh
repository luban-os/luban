#!/bin/sh

interface=`cat /proc/net/dev | awk '/^w/' | awk -F ':' '{print $1}'`

iwlist $interface scanning | grep -i ssid
