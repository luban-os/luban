#!/bin/sh

interface=`cat /proc/net/dev | awk '/^w/' | awk -F ':' '{print $1}'`

nmcli device disconnect $interface
