#!/bin/sh

nmcli r wifi off
