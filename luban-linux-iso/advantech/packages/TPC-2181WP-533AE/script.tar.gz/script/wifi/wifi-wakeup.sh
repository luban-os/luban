#!/bin/sh

nmcli r wifi on
