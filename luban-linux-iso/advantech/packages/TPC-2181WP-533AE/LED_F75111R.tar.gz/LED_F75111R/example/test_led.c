#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define LED_MAGIC       'p'
#define LED_ON          _IO(LED_MAGIC, 0)
#define LED_OFF         _IO(LED_MAGIC, 1)

typedef unsigned char u8;

int main(void)
{
    int ignore_ret = 0;
    int ret = 0;
    int fd;
    int status;
    int tmp_status;
    u8 tmp_num;
    u8 led_num;

    if ((fd = open("/dev/advled", O_RDWR)) < 0 )
    {
        printf("Can not open advled device!\n");
        return -1;
    }

    printf("Please input the led index.\n");
    printf("The index ragnge(0x16,0x17,0x20,0x21):\n");
    ignore_ret = scanf("%hhx",&tmp_num);

    if((tmp_num != 0x16) && (tmp_num != 0x17) && (tmp_num != 0x20) && (tmp_num != 0x21))
    {
        printf("GPIO index range:(0x16,0x17,0x20,0x21)\n");
        ret = -1;
        goto ERROR;
    }else{
        led_num = tmp_num;
    }

    printf("Please input the LED status.(0:OUTPUT_LOW, 1:OUTPUT_HIGH):\n");
    ignore_ret = scanf("%u", &tmp_status);

    if (tmp_status == 1)
     {
         status = ioctl(fd, LED_ON, &led_num);
         if (status != 0){
             printf("Set LED status failed\n");
             ret = -1;
             goto ERROR;
         }
         else{
             printf("OK\n");
         }
     }
     else
     {
         status = ioctl(fd, LED_OFF, &led_num);
         if (status != 0){
             printf("Set LED status failed\n");
             ret = -1;
             goto ERROR;
         }
         else{
             printf("OK\n");
         }
     }

ERROR:
    close(fd);
    return ret;
}
